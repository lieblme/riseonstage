# RiseOnStage Website

Welcome to the official **RiseOnStage** website.

This is a static site built using HTML and CSS. It features:
- Event listings
- About and contact sections
- Clean, mobile-responsive design

## 🚀 Deployment
To host this site using **GitHub Pages**:

1. Create a new public repository on GitHub (e.g., `riseonstage`).
2. Upload `index.html` and `README.md` to the root of the repository.
3. Go to **Settings** → **Pages**
4. Under "Source", select the `main` branch and root folder.
5. GitHub will give you a live URL like: `https://yourusername.github.io/riseonstage/`

Enjoy! 🌟
