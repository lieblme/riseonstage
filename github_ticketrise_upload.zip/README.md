# TicketRise Website

This is a simple ticket booking website called **TicketRise**.

- Built using HTML and CSS.
- Mobile responsive.
- Includes Home, About, Events, and Contact sections.

## How to Deploy
You can deploy this site easily using GitHub Pages:

1. Upload these files to a new GitHub repository.
2. Go to Settings → Pages → Set Source to the `main` branch.
3. Your site will be live at: `https://yourusername.github.io/repositoryname/`

Enjoy! 🚀
